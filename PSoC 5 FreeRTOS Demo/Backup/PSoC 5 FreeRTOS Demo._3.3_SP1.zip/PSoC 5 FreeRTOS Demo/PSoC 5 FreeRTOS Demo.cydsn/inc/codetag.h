/*
*********************************************************************************************************
*
*                                            MUX ADVANCE CODE
*
*                                             CYPRESS PSoC5LP
*                                                with the
*                                            CY8C5969AXI-LP035
*
* Filename      : codetag.h
* Version       : V1.00
* Programmer(s) : 
                  
*********************************************************************************************************
*/

#ifndef CODETAG_H
#define CODETAG_H
#include <device.h>
	
uint8 serial_codetag(uint8 side);

#endif

//[] END OF FILE
